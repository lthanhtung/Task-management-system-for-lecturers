<?php
ob_start();
require_once '../Layout/header.php';
require_once BASE_PATH . './Database/connect-database.php';

$id = $_GET['MaGiangVien'];

// Kiểm tra quyền và lấy MaKhoa của Admin
$user_id = $_SESSION['user_id'];
$quyen = $_SESSION['quyen'] ?? 'Không xác định';
$ma_khoa = null;
$ten_khoa = null;

if ($quyen === 'Admin') {
    // Lấy MaKhoa và TenKhoa của Admin từ bảng giangvien
    $query_khoa = "SELECT g.MaKhoa, k.TenKhoa 
                   FROM giangvien g 
                   JOIN khoa k ON g.MaKhoa = k.MaKhoa 
                   WHERE g.MaGiangVien = ?";
    $stmt_khoa = $dbc->prepare($query_khoa);
    $stmt_khoa->bind_param("s", $user_id);
    $stmt_khoa->execute();
    $result_khoa = $stmt_khoa->get_result();

    if ($row_khoa = $result_khoa->fetch_assoc()) {
        $ma_khoa = $row_khoa['MaKhoa'];
        $ten_khoa = $row_khoa['TenKhoa'];
    }
    $stmt_khoa->close();
}

// Lấy thông tin giảng viên
$sql = "
    SELECT giangvien.*, khoa.TenKhoa
    FROM giangvien
    JOIN khoa ON giangvien.MaKhoa = khoa.MaKhoa
    WHERE giangvien.MaGiangVien = '$id'";
$result = mysqli_query($dbc, $sql);
$rows = mysqli_fetch_array($result);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $errors = array();

    // Kiểm tra họ giảng viên
    if (empty($_POST['HoGiangVien'])) {
        $errors['HoGiangVien'] = 'Họ giảng viên không để trống';
    } else {
        $HoGiangVien = mysqli_real_escape_string($dbc, trim($_POST['HoGiangVien']));
    }

    // Kiểm tra Tên giảng viên
    if (empty($_POST['TenGiangVien'])) {
        $errors['TenGiangVien'] = 'Tên giảng viên không để trống';
    } else {
        $TenGiangVien = mysqli_real_escape_string($dbc, trim($_POST['TenGiangVien']));
    }

    // Ngày sinh
    if (isset($_POST['NgaySinh'])) {
        $NgaySinh = mysqli_real_escape_string($dbc, trim($_POST['NgaySinh']));
    }

    // Giới tính
    if (isset($_POST['GioiTinh'])) {
        $GioiTinh = ($_POST['GioiTinh'] === 'nam') ? 1 : 2;
    }

    // Kiểm tra Email
    if (empty($_POST['Email'])) {
        $errors['Email'] = 'Email không để trống!';
    } else {
        if (strpos($_POST['Email'], '@') === false) {
            $errors['Email'] = 'Email phải chứa ký tự @!';
        } else {
            $Email = mysqli_real_escape_string($dbc, trim($_POST['Email']));
            $sql = "SELECT * FROM giangvien WHERE Email = '$Email' AND MaGiangVien != '$id'";
            $result = mysqli_query($dbc, $sql);
            if (mysqli_num_rows($result) > 0) {
                $errors['Email'] = 'Email đã có người sử dụng';
            }
        }
    }

    // Kiểm tra Số điện thoại
    if (empty($_POST['SDT'])) {
        $errors['SDT'] = 'Số điện thoại không để trống';
    } else {
        $SDT = trim($_POST['SDT']);
        if (!is_numeric($SDT) || substr($SDT, 0, 1) != '0' || strlen($SDT) != 11) {
            $errors['SDT'] = 'Số điện thoại phải là số và bắt đầu bằng 0 với đúng 11 số';
        } else {
            $SDT = mysqli_real_escape_string($dbc, $SDT);
        }
    }

    // Kiểm tra Học vị
    if (isset($_POST['HocVi'])) {
        $hocvi = ($_POST['HocVi'] === 'thac') ? 'Thạc sĩ' : 'Tiến sĩ';
    }

    // Chức danh
    if (isset($_POST['ChucDanh'])) {
        $chucdanh_options = [
            'trg' => 'Trợ giảng',
            'gv' => 'Giảng viên',
            'gvc' => 'Giảng viên chính',
            'phogs' => 'Phó giáo sư',
            'gs' => 'Giáo sư'
        ];
        $chucdanh = $chucdanh_options[$_POST['ChucDanh']] ?? 'Giảng viên';
    }

    // Khoa
    if ($quyen === 'Admin' && $ma_khoa !== null) {
        $Khoa = $ma_khoa;
        $tenKhoa = $ten_khoa;
    } elseif (isset($_POST['Khoa'])) {
        $Khoa = mysqli_real_escape_string($dbc, trim($_POST['Khoa']));
    } else {
        $errors['Khoa'] = 'Vui lòng chọn khoa';
    }

    // Kiểm tra trạng thái
    if (isset($_POST['TrangThai'])) {
        $trangthai_options = [
            'day' => 1,
            'nghi' => 2,
            'chuyen' => 3
        ];
        $trangthai = $trangthai_options[$_POST['TrangThai']] ?? 1;
    }

    // Xử lý ảnh đại diện
    $imagePathForDB = $rows['AnhDaiDien'];
    if (isset($Khoa) && empty($errors)) {
        $MaKhoa = $Khoa;
        $queryKhoa = "SELECT TenKhoa FROM khoa WHERE MaKhoa = '$MaKhoa' AND TrangThai = 1";
        $resultKhoa = mysqli_query($dbc, $queryKhoa);

        if ($resultKhoa && mysqli_num_rows($resultKhoa) > 0) {
            $rowKhoa = mysqli_fetch_assoc($resultKhoa);
            $tenKhoa = $rowKhoa['TenKhoa'];

            // Đường dẫn thư mục khoa
            $facultyPath = BASE_PATH . '/Public/img/faculty/' . $tenKhoa;

            // Tạo thư mục nếu chưa tồn tại
            if (!file_exists($facultyPath)) {
                if (!mkdir($facultyPath, 0777, true)) {
                    $errors['system'] = 'Không thể tạo thư mục cho khoa ' . $tenKhoa;
                }
            }

            // Xử lý ảnh nếu người dùng chọn ảnh mới
            if (isset($_FILES['anhdaidien']) && $_FILES['anhdaidien']['error'] == 0) {
                $file = $_FILES['anhdaidien'];
                $fileExtension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
                $allowedTypes = array('jpg', 'jpeg', 'png', 'gif');

                $fileName = $HoGiangVien . '_' . $TenGiangVien . '.' . $fileExtension;
                $destination = $facultyPath . '/' . $fileName;
                $imagePathForDB = BASE_URL . '/Public/img/faculty/' . $tenKhoa . '/' . $fileName;

                if (!in_array($fileExtension, $allowedTypes)) {
                    $errors['anhdaidien'] = 'Chỉ chấp nhận file JPG, JPEG, PNG hoặc GIF';
                } elseif ($file['size'] > 5 * 1024 * 1024) {
                    $errors['anhdaidien'] = 'Kích thước file không được vượt quá 5MB';
                } else {
                    // Xóa ảnh cũ nếu tồn tại (trừ ảnh mặc định)
                    $oldImagePath = BASE_PATH . str_replace(BASE_URL, '', $rows['AnhDaiDien']);
                    if (file_exists($oldImagePath) && strpos($oldImagePath, 'avatar-default.png') === false) {
                        unlink($oldImagePath);
                    }

                    // Upload ảnh mới
                    if (!move_uploaded_file($file['tmp_name'], $destination)) {
                        $errors['anhdaidien'] = 'Không thể upload ảnh đại diện';
                    }
                }
            }
        } else {
            $errors['Khoa'] = 'Khoa không tồn tại hoặc không hoạt động';
        }
    }

    if (empty($errors)) {
        // Cập nhật thông tin giảng viên
        $queryGiangVien = "
        UPDATE giangvien 
        SET 
            HoGiangVien = '$HoGiangVien',
            TenGiangVien = '$TenGiangVien',
            NgaySinh = '$NgaySinh',
            GioiTinh = '$GioiTinh',
            Email = '$Email',
            SoDienThoai = '$SDT',
            HocVi = '$hocvi',
            ChucDanh = '$chucdanh',
            MaKhoa = '$Khoa',
            TrangThai = '$trangthai',
            AnhDaiDien = '$imagePathForDB'
        WHERE MaGiangVien = '$id'";

        $r1 = @mysqli_query($dbc, $queryGiangVien);

        session_start();
        if ($r1) {
            $_SESSION['success_message'] = 'Cập nhật thông tin giảng viên thành công!';
            header("Location: index.php");
            ob_end_flush();
            exit();
        } else {
            echo '<h1>Lỗi Hệ Thống</h1>';
            echo '<p>' . mysqli_error($dbc) . '<br />Truy vấn: ' . $queryGiangVien . '</p>';
        }
        mysqli_close($dbc);
        exit();
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chỉnh sửa Giảng Viên</title>
    <link rel="stylesheet" href="<?php echo BASE_URL ?>/Public/plugins/fontawesome-free/css/all.min.css">
    <link rel="stylesheet" href="<?php echo BASE_URL ?>/Public/dist/css/adminlte.min.css">
</head>

<body>
    <div class="content-wrapper">
        <section class="content my-2">
            <div class="card">
                <div class="card-header">
                    <strong class="text-danger">CHỈNH SỬA GIẢNG VIÊN</strong>
                    <a href="./index.php" class="btn-sm btn-info float-right"><i class="fa fa-long-arrow-alt-left"></i> Quay lại</a>
                </div>
                <form action="" method="post" enctype="multipart/form-data">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-9">
                                <div class="form-group">
                                    <label>Mã Giảng Viên <span class="text-danger"> (*)</span></label>
                                    <input class="form-control" type="text" name="MaGiangVien" value="<?php echo $rows['MaGiangVien']; ?>" readonly>
                                </div>
                                <div class="form-group">
                                    <label>Họ Giảng Viên <span class="text-danger"> (*)</span></label>
                                    <input class="form-control" type="text" name="HoGiangVien" value="<?php echo $rows['HoGiangVien']; ?>">
                                    <?php if (isset($errors['HoGiangVien'])): ?>
                                        <small class="text-danger"><?php echo $errors['HoGiangVien']; ?></small>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label>Tên Giảng Viên <span class="text-danger"> (*)</span></label>
                                    <input class="form-control" type="text" name="TenGiangVien" value="<?php echo $rows['TenGiangVien']; ?>">
                                    <?php if (isset($errors['TenGiangVien'])): ?>
                                        <small class="text-danger"><?php echo $errors['TenGiangVien']; ?></small>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label>Email <span class="text-danger"> (*)</span></label>
                                    <input class="form-control" type="text" name="Email" value="<?php echo $rows['Email']; ?>">
                                    <?php if (isset($errors['Email'])): ?>
                                        <small class="text-danger"><?php echo $errors['Email']; ?></small>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label>Trạng Thái <span class="text-danger">(*)</span></label>
                                    <select class="form-control" name="TrangThai">
                                        <option value="day" <?php echo ($rows['TrangThai'] == 1) ? 'selected' : ''; ?>>Đang dạy</option>
                                        <option value="nghi" <?php echo ($rows['TrangThai'] == 2) ? 'selected' : ''; ?>>Về hưu</option>
                                        <option value="chuyen" <?php echo ($rows['TrangThai'] == 3) ? 'selected' : ''; ?>>Chuyển công tác</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label>Ảnh đại diện <span class="text-danger">(*)</span></label>
                                    <div class="col-md-6">
                                        <img src="<?php echo $rows['AnhDaiDien']; ?>" alt="Ảnh đại diện" style="width: 100px; height: auto; margin-bottom: 10px;">
                                        <input type="file" class="form-control" name="anhdaidien" style="width: auto;">
                                        <?php if (isset($errors['anhdaidien'])): ?>
                                            <small class="text-danger"><?php echo $errors['anhdaidien']; ?></small>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Ngày sinh <span class="text-danger">(*)</span></label>
                                    <input type="date" class="form-control" name="NgaySinh" value="<?php echo $rows['NgaySinh']; ?>" required>
                                </div>
                                <?php if ($quyen !== 'Admin'): ?>
                                    <div class="form-group">
                                        <label>Khoa <span class="text-danger">(*)</span></label>
                                        <select class="form-control" name="Khoa">
                                            <?php
                                            $sql = "SELECT * FROM khoa WHERE TrangThai=1";
                                            $result = mysqli_query($dbc, $sql);
                                            while ($row = mysqli_fetch_array($result)) {
                                                $selected = ($row['MaKhoa'] == $rows['MaKhoa']) ? 'selected' : '';
                                                echo "<option value='{$row['MaKhoa']}' $selected>{$row['TenKhoa']}</option>";
                                            }
                                            ?>
                                        </select>
                                        <?php if (isset($errors['Khoa'])): ?>
                                            <small class="text-danger"><?php echo $errors['Khoa']; ?></small>
                                        <?php endif; ?>
                                    </div>
                                <?php else: ?>
                                    <div class="form-group">
                                        <label>Khoa <span class="text-danger">(*)</span></label>
                                        <input type="hidden" name="Khoa" value="<?php echo htmlspecialchars($ma_khoa); ?>">
                                        <p><?php echo htmlspecialchars($ten_khoa); ?></p>
                                    </div>
                                <?php endif; ?>
                                <div class="form-group">
                                    <label>Giới tính <span class="text-danger">(*)</span></label>
                                    <select class="form-control" name="GioiTinh">
                                        <option value="nam" <?php echo ($rows['GioiTinh'] == 1) ? 'selected' : ''; ?>>Nam</option>
                                        <option value="nu" <?php echo ($rows['GioiTinh'] == 2) ? 'selected' : ''; ?>>Nữ</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Số điện thoại <span class="text-danger"> (*)</span></label>
                                    <input class="form-control" type="text" name="SDT" value="<?php echo $rows['SoDienThoai']; ?>">
                                    <?php if (isset($errors['SDT'])): ?>
                                        <small class="text-danger"><?php echo $errors['SDT']; ?></small>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label>Học vị <span class="text-danger">(*)</span></label>
                                    <select class="form-control" name="HocVi">
                                        <option value="thac" <?php echo ($rows['HocVi'] == 'Thạc sĩ') ? 'selected' : ''; ?>>Thạc sĩ</option>
                                        <option value="tien" <?php echo ($rows['HocVi'] == 'Tiến sĩ') ? 'selected' : ''; ?>>Tiến sĩ</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Chức danh <span class="text-danger">(*)</span></label>
                                    <select class="form-control" name="ChucDanh">
                                        <option value="trg" <?php echo ($rows['ChucDanh'] == 'Trợ giảng') ? 'selected' : ''; ?>>Trợ giảng</option>
                                        <option value="gv" <?php echo ($rows['ChucDanh'] == 'Giảng viên') ? 'selected' : ''; ?>>Giảng viên</option>
                                        <option value="gvc" <?php echo ($rows['ChucDanh'] == 'Giảng viên chính') ? 'selected' : ''; ?>>Giảng viên chính</option>
                                        <option value="phogs" <?php echo ($rows['ChucDanh'] == 'Phó giáo sư') ? 'selected' : ''; ?>>Phó giáo sư</option>
                                        <option value="gs" <?php echo ($rows['ChucDanh'] == 'Giáo sư') ? 'selected' : ''; ?>>Giáo sư</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-md-offset-2 col-md-12">
                                    <button class="btn-sm btn-success" type="submit" name="create"> Lưu [Cập nhật] <i class="fa fa-save"></i> </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </section>
    </div>

    <script src="<?php echo BASE_URL ?>/Public/plugins/jquery/jquery.min.js"></script>
    <script src="<?php echo BASE_URL ?>/Public/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo BASE_URL ?>/Public/dist/js/adminlte.min.js"></script>
</body>

</html>

<?php
require_once '../Layout/footer.php';
?>