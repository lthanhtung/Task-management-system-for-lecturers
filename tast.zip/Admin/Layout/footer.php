<!-- Footer -->
<div class="wrapper">
    <footer class="main-footer">
        <strong>Copyright &copy; <a href="#">Lê Thanh Tùng</a>.</strong>
        All rights reserved.
    </footer>
</div>