<?php
ob_start();
require_once '../Layout/header.php';
require_once BASE_PATH . './Database/connect-database.php';

// Lấy mã học phần cần edit từ GET
$id = $_GET['MaHocPhan'];

// Kiểm tra quyền và lấy MaKhoa của Admin
$user_id = $_SESSION['user_id'];
$quyen = $_SESSION['quyen'] ?? 'Không xác định';
$ma_khoa = null;
$ten_khoa = null;

if ($quyen === 'Admin') {
    // Lấy MaKhoa và TenKhoa của Admin từ bảng giangvien
    $query_khoa = "SELECT g.MaKhoa, k.TenKhoa 
                   FROM giangvien g 
                   JOIN khoa k ON g.MaKhoa = k.MaKhoa 
                   WHERE g.MaGiangVien = ?";
    $stmt_khoa = $dbc->prepare($query_khoa);
    $stmt_khoa->bind_param("s", $user_id);
    $stmt_khoa->execute();
    $result_khoa = $stmt_khoa->get_result();

    if ($row_khoa = $result_khoa->fetch_assoc()) {
        $ma_khoa = $row_khoa['MaKhoa'];
        $ten_khoa = $row_khoa['TenKhoa'];
    }
    $stmt_khoa->close();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $errors = array();

    // Kiểm tra Mã học phần
    if (empty($_POST['MaHocPhan'])) {
        $errors['MaHocPhan'] = 'Mã học phần không để trống!';
    } else {
        $MaHocPhan = mysqli_real_escape_string($dbc, trim($_POST['MaHocPhan']));
        $sql = "SELECT * FROM hocphan WHERE MaHocPhan = '$MaHocPhan' AND MaHocPhan != '$id'";
        $result = mysqli_query($dbc, $sql);

        if (mysqli_num_rows($result) > 0) {
            $errors['MaHocPhan'] = 'Mã học phần bị trùng';
        }
    }

    // Kiểm tra Tên học phần
    if (empty($_POST['TenHocPhan'])) {
        $errors['TenHocPhan'] = 'Tên học phần không để trống';
    } else {
        $TenHocPhan = mysqli_real_escape_string($dbc, trim($_POST['TenHocPhan']));
    }

    // Khoa
    if ($quyen === 'Admin' && $ma_khoa !== null) {
        $Khoa = $ma_khoa;
    } elseif (isset($_POST['Khoa'])) {
        $Khoa = mysqli_real_escape_string($dbc, trim($_POST['Khoa']));
    } else {
        $errors['Khoa'] = 'Vui lòng chọn khoa';
    }

    // Trạng thái
    if (isset($_POST['TrangThai'])) {
        $trangthai = ($_POST['TrangThai'] === 'xuat') ? 1 : 2;
    }

    if (empty($errors)) {
        $q = "UPDATE hocphan SET 
              MaHocPhan = '$MaHocPhan',
              TenHocPhan = '$TenHocPhan',
              MaKhoa = '$Khoa',
              TrangThai = '$trangthai'		
              WHERE MaHocPhan = '$id'";
        $r = @mysqli_query($dbc, $q);
        session_start();
        if ($r) {
            $_SESSION['success_message'] = 'Cập nhật học phần thành công!';
            header("Location: index.php");
            ob_end_flush();
            exit();
        } else {
            echo '<h1>System Error</h1>
                  <p class="error">You could not be registered due to a system error. We apologize for any inconvenience.</p>';
            echo '<p>' . mysqli_error($dbc) . '<br /><br />Query: ' . $q . '</p>';
        }
        mysqli_close($dbc);
        exit();
    }
} else {
    // Lấy thông tin học phần từ cơ sở dữ liệu để hiển thị
    $sql = "SELECT * FROM hocphan WHERE MaHocPhan = '$id'";
    $result = mysqli_query($dbc, $sql);
    $rows = mysqli_fetch_array($result);
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cập nhật học phần</title>
    <link rel="stylesheet" href="<?php echo BASE_URL ?>/Public/plugins/fontawesome-free/css/all.min.css">
    <link rel="stylesheet" href="<?php echo BASE_URL ?>/Public/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="<?php echo BASE_URL ?>/Public/plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
    <link rel="stylesheet" href="<?php echo BASE_URL ?>/Public/plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
    <link rel="stylesheet" href="<?php echo BASE_URL ?>/Public/dist/css/adminlte.min.css">
</head>

<body>
    <div class="content-wrapper">
        <section class="content my-2">
            <div class="card">
                <div class="card-header">
                    <div class="row">
                        <div class="col-md-6">
                            <strong class="text-danger">CẬP NHẬT HỌC PHẦN</strong>
                        </div>
                        <div class="col-md-6 text-right">
                            <a href="./index.php" class="btn-sm btn-info"> <i class="fa fa-long-arrow-alt-left"></i> Quay lại</a>
                        </div>
                    </div>
                </div>
                <form action="" method="post">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-9">
                                <div class="form-group">
                                    <label>Mã học phần <span class="text-danger"> (*)</span></label>
                                    <div class="col">
                                        <input class="form-control" type="text" name="MaHocPhan"
                                            value="<?php if (isset($_POST['MaHocPhan'])) echo htmlspecialchars($_POST['MaHocPhan']);
                                                    else echo htmlspecialchars($rows['MaHocPhan']); ?>">
                                        <?php if (isset($errors['MaHocPhan'])): ?>
                                            <small class="text-danger"><?php echo $errors['MaHocPhan']; ?></small>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label>Tên học phần <span class="text-danger"> (*)</span></label>
                                    <div class="col">
                                        <input class="form-control" type="text" name="TenHocPhan"
                                            value="<?php if (isset($_POST['TenHocPhan'])) echo htmlspecialchars($_POST['TenHocPhan']);
                                                    else echo htmlspecialchars($rows['TenHocPhan']); ?>">
                                        <?php if (isset($errors['TenHocPhan'])): ?>
                                            <small class="text-danger"><?php echo $errors['TenHocPhan']; ?></small>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <?php if ($quyen !== 'Admin'): ?>
                                    <div class="form-group">
                                        <label>Khoa <span class="text-danger">(*)</span></label>
                                        <div class="col-md-7">
                                            <select class="form-control" name="Khoa" style="width: auto;">
                                                <?php
                                                $sql = "SELECT * FROM khoa WHERE TrangThai=1";
                                                $result = mysqli_query($dbc, $sql);
                                                if (mysqli_num_rows($result) > 0) {
                                                    while ($row = mysqli_fetch_array($result)) {
                                                        $selected = ($row['MaKhoa'] == $rows['MaKhoa']) ? 'selected' : '';
                                                        echo "<option value='$row[MaKhoa]' $selected>$row[TenKhoa]</option>";
                                                    }
                                                }
                                                ?>
                                            </select>
                                            <?php if (isset($errors['Khoa'])): ?>
                                                <small class="text-danger"><?php echo $errors['Khoa']; ?></small>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <div class="form-group">
                                        <label>Khoa <span class="text-danger">(*)</span></label>
                                        <div class="col-md-7">
                                            <input type="hidden" name="Khoa" value="<?php echo htmlspecialchars($ma_khoa); ?>">
                                            <p><?php echo htmlspecialchars($ten_khoa); ?></p>
                                        </div>
                                    </div>
                                <?php endif; ?>
                                <div class="form-group">
                                    <label>Trạng Thái <span class="text-danger">(*)</span></label>
                                    <div class="col-md-5">
                                        <select class="form-control" name="TrangThai">
                                            <option value="xuat" <?php echo ($rows['TrangThai'] == 1) ? 'selected' : ''; ?>>Xuất bản</option>
                                            <option value="an" <?php echo ($rows['TrangThai'] == 2) ? 'selected' : ''; ?>>Ẩn</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-md-offset-2 col-md-12">
                                    <button class="btn-sm btn-success" type="submit" name="create"> Cập nhật <i class="fa fa-save"></i> </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </section>
    </div>

    <script src="<?php echo BASE_URL ?>/Public/plugins/jquery/jquery.min.js"></script>
    <script src="<?php echo BASE_URL ?>/Public/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo BASE_URL ?>/Public/plugins/datatables/jquery.dataTables.min.js"></script>
    <script src="<?php echo BASE_URL ?>/Public/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
    <script src="<?php echo BASE_URL ?>/Public/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
    <script src="<?php echo BASE_URL ?>/Public/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
    <script src="<?php echo BASE_URL ?>/Public/plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
    <script src="<?php echo BASE_URL ?>/Public/plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
    <script src="<?php echo BASE_URL ?>/Public/plugins/jszip/jszip.min.js"></script>
    <script src="<?php echo BASE_URL ?>/Public/plugins/pdfmake/pdfmake.min.js"></script>
    <script src="<?php echo BASE_URL ?>/Public/plugins/pdfmake/vfs_fonts.js"></script>
    <script src="<?php echo BASE_URL ?>/Public/plugins/datatables-buttons/js/buttons.html5.min.js"></script>
    <script src="<?php echo BASE_URL ?>/Public/plugins/datatables-buttons/js/buttons.print.min.js"></script>
    <script src="<?php echo BASE_URL ?>/Public/plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
    <script src="<?php echo BASE_URL ?>/Public/dist/js/adminlte.min.js"></script>
    <script src="<?php echo BASE_URL ?>/Public/dist/js/demo.js"></script>
    <script>
        $(function() {
            $("#example1").DataTable({
                "responsive": true,
                "lengthChange": false,
                "autoWidth": false,
            }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
            $('#example2').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": false,
                "ordering": true,
                "info": true,
                "autoWidth": false,
                "responsive": true,
            });
        });
    </script>
</body>

</html>

<?php
require_once '../Layout/footer.php';
?>