<?php
// Nạp file config để sử dụng đường dẫn đã thiết lập
require_once '../config.php';
?>

<footer class="py-3">
    <div class="container text-center">
        <p class="mb-1">Trường Đại Học Nha Trang (Nha Trang University)</p>
        <p class="mb-1">Số 02 Nguyễn Đình Chiểu - Nha Trang - Khánh Hòa</p>
        <p class="mb-0">Tel: 0583 831 149 | Fax: 0583 831 147</p>
    </div>
</footer>